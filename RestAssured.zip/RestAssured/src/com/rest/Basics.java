package com.rest;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import org.testng.*;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import static org.hamcrest.Matchers.*;

import static io.restassured.RestAssured.given;

public class Basics {

	@Test(dataProvider = "addplacesDataProvider")
	public void TestMethod(String name, String language) {

		RestAssured.baseURI = "http://216.10.245.166";
		String add_payload = "{      \"location\":{          \"lat\" : -36.383494,          \"lng\" : 21.427362      },      \"accuracy\":40"
				+ 30 + ",      \"name\":\"" + name
				+ "\",      \"phone_number\":\"(+91) 983 893 9898\",      \"address\" : \"" + 40
				+ ", side layout, cohen 09\",      \"types\": [\"shoe park\",\"shop\"],      \"website\" : \"http://google.com\",      \"language\" : \""
				+ language + "\"  } ";

		// RestAssured.baseURI =
		// "https://community-open-weather-map.p.rapidapi.com";

		Response res = given().urlEncodingEnabled(true).queryParam("key", "qaclick123").body(add_payload).when()
				.post("/maps/api/place/add/json");

		String responseString = res.asString();
		System.err.println(responseString);

		JsonPath jsonpath = new JsonPath(responseString);
		System.err.println("Retrieved Place ID is: " + jsonpath.get("place_id"));

		String placeid = jsonpath.get("place_id");

		System.err.println(placeid);

		// Now delete the added place using place id delete API

		// String delete_payload = "";

		/*
		 * String tm = "{\"place_id\": \"" + placeid + "\"}";
		 * 
		 * System.err.println("-----" + tm + "-----");
		 * 
		 * Response resdel = given().urlEncodingEnabled(true).queryParam("key",
		 * "qaclick123").body(tm).when() .post("/maps/api/place/delete/json");
		 * 
		 * String respdeleteString = resdel.asString();
		 * 
		 * System.err.println("Delete API response:" + respdeleteString);
		 * 
		 * JsonPath jsonPathDel = new JsonPath(respdeleteString);
		 * System.err.println("Place deleted : " +
		 * jsonPathDel.get("status").equals("OK"));
		 */

		/*
		 * given().param("type", "link%2C accurate").param("units",
		 * "imperial%2C metric").param("q", "london") .header("x-rapidapi-host",
		 * "community-open-weather-map.p.rapidapi.com")
		 * .header("x-rapidapi-key",
		 * "ab1fd370b6mshb72f74cbea5c95ap18a931jsn09a6aff341b6")
		 * .header("useQueryString",
		 * true).when().get("/find").getBody().prettyPrint();
		 */

		/*
		 * given().param("type", "link%2C accurate").param("units",
		 * "imperial%2C metric").param("q", "london") .header("x-rapidapi-host",
		 * "community-open-weather-map.p.rapidapi.com")
		 * .header("x-rapidapi-key",
		 * "ab1fd370b6mshb72f74cbea5c95ap18a931jsn09a6aff341b6")
		 * .header("useQueryString",
		 * true).when().get("/find").then().assertThat().statusCode(200).and()
		 * .body("list[0].id", equalToObject("2643743"));
		 * 
		 */

	}

	@DataProvider(name = "addplacesDataProvider")
	public Object[][] getData() {
		return new Object[][] { { "Batla House", "English" }, { "DUmper Road", "UK" }, { "White House", "Austria" } };
	}

}
