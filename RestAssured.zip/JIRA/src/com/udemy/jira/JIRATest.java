package com.udemy.jira;
import org.testng.annotations.BeforeTest;

import org.testng.annotations.Test;


import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

import static io.restassured.RestAssured.*;

public class JIRATest {

	public String getSessionKey() {

		RestAssured.baseURI = "http://localhost:8080";

		Response res = given().header("Content-Type", "Application/json")
				.body("{\"username\": \"myquoraismine29\",\"password\":\"dost1234\"}").when()
				.post("/rest/auth/1/session").then().extract().response();

		String stringResp = res.asString();

		JsonPath jsonpath = new JsonPath(stringResp);

		System.err.println("JSESSIONID: " + jsonpath.get("session.value"));
		return jsonpath.get("session.value");
	}

	@Test
	public void login() {

		String payload = "{\n  \"fields\": {\n    \"project\": {\n      \"key\": \"RES\"\n    },\n    \"summary\": \"This is non- scritical bug\",\n    \"issuetype\": {\n      \"name\": \"Bug\"\n    },\n    \"description\": \"description\",\n     \"labels\": [\n            \"bugfix\",\n            \"blitz_test\"\n        ]\n  }\n}";

		RestAssured.baseURI = "http://localhost:8080";

		Response resp = given().header("Content-Type", "Application/json")
				.header("Cookie", "JSESSIONID=" + getSessionKey()).body(payload).when().post("/rest/api/2/issue").then()
				.statusCode(201).extract().response();

		String stringResponse = resp.asString();

		JsonPath jsonPath = new JsonPath(stringResponse);
		System.err.println("response: " + jsonPath.get("id") + jsonPath.get("key") + jsonPath.get("self"));

	}

}
